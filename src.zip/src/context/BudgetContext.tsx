'use client';

import { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { Budget, BudgetFormData, BudgetStatus } from "@/types/budget";
import { toast } from "sonner";
import { 
  getEvents, 
  createEvent, 
  updateEvent, 
  deleteEvent 
} from "@/utils/api";
import { useAuth } from "@/hooks/useAuth";

const mapStatusToApi = (status: BudgetStatus) => {
  const mapping = {
    pending: "orcamento_recebido",
    sent: "proposta_enviada",
    accepted: "proposta_aceita",
    rejected: "proposta_recusada"
  };
  return mapping[status];
};

const mapApiToStatus = (apiStatus: string): BudgetStatus => {
  const mapping: Record<string, BudgetStatus> = {
    orcamento_recebido: "pending",
    proposta_enviada: "sent",
    proposta_aceita: "accepted",
    proposta_recusada: "rejected"
  };
  return mapping[apiStatus] || "pending";
};

const budgetToApiFormat = (budget: BudgetFormData, status: BudgetStatus, rejectionReason?: string) => {
  const apiData: Record<string, any> = {
    nomeCliente: budget.clientName,
    tipoEvento: budget.eventType,
    dataOrcamento: budget.budgetDate.toISOString().split('T')[0],
    dataEvento: budget.eventDate.toISOString().split('T')[0],
    status: mapStatusToApi(status)
  };

  if (status === 'sent' || status === 'accepted') {
    apiData.valorEvento = budget.amount !== undefined ? Number(budget.amount) : 0;
  }

  if (status === 'accepted') {
    apiData.iraParcelar = budget.installments;
    apiData.quantParcelas = Number(budget.installmentsCount);
    apiData.dataPrimeiroPagamento = budget.firstPaymentDate?.toISOString().split('T')[0];
  }

  if (budget.phone) {
    apiData.contatoCliente = budget.phone;
  }

  if (status === "rejected") {
    apiData.motivoRecusa = rejectionReason ?? "Motivo não informado";
  }

  return Object.fromEntries(
    Object.entries(apiData).filter(([_, v]) => v !== undefined)
  );
};

const apiToBudgetFormat = (apiData: any): Budget => {
  return {
    id: apiData.id.toString(),
    clientName: apiData.nomeCliente,
    phone: apiData.contatoCliente || "",
    budgetDate: new Date(apiData.dataOrcamento),
    eventDate: new Date(apiData.dataEvento),
    eventType: apiData.tipoEvento,
    amount: apiData.valorEvento,
    installments: apiData.iraParcelar || false,
    installmentsCount: apiData.quantParcelas || 1,
    firstPaymentDate: apiData.dataPrimeiroPagamento ? new Date(apiData.dataPrimeiroPagamento) : undefined,
    status: mapApiToStatus(apiData.status),
    createdAt: new Date(apiData.created_at || new Date()),
    updatedAt: new Date(apiData.updated_at || new Date())
  };
};

interface BudgetContextType {
  budgets: Budget[];
  isLoading: boolean;
  error: string | null;
  addBudget: (budgetData: BudgetFormData) => Promise<void>;
  updateBudget: (id: string, budgetData: BudgetFormData) => Promise<void>;
  deleteBudget: (id: string) => Promise<void>;
  updateStatus: (id: string, newStatus: BudgetStatus, data?: any) => Promise<void>;
  getBudget: (id: string) => Budget | undefined;
  refreshBudgets: () => Promise<void>;
}

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

export function useBudgets() {
  const context = useContext(BudgetContext);
  if (context === undefined) {
    throw new Error("useBudgets must be used within a BudgetProvider");
  }
  return context;
}

export function BudgetProvider({ children }: { children: ReactNode }) {
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  const fetchBudgets = async () => {
    if (!isAuthenticated) return;
    setIsLoading(true);
    setError(null);
    try {
      const data = await getEvents();
      const formattedBudgets = data.map(apiToBudgetFormat);
      setBudgets(formattedBudgets);
    } catch (error) {
      console.error("Error fetching budgets:", error);
      setError("Falha ao carregar orçamentos");
      toast.error("Falha ao carregar orçamentos");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchBudgets();
    }
  }, [isAuthenticated]);

  const addBudget = async (budgetData: BudgetFormData) => {
    setIsLoading(true);
    try {
      const apiData = budgetToApiFormat(budgetData, "pending");
      const response = await createEvent(apiData);
      const newBudget = apiToBudgetFormat(response);
      setBudgets((prevBudgets) => [...prevBudgets, newBudget]);
      toast.success("Orçamento criado com sucesso!");
    } catch (error) {
      console.error("Error adding budget:", error);
      toast.error("Falha ao criar orçamento");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateBudget = async (id: string, budgetData: BudgetFormData) => {
    setIsLoading(true);
    try {
      const budget = budgets.find(b => b.id === id);
      if (!budget) throw new Error("Orçamento não encontrado");
      const apiData = budgetToApiFormat(budgetData, budget.status);
      const response = await updateEvent(parseInt(id), apiData);
      const updatedBudget = apiToBudgetFormat(response);
      setBudgets((prevBudgets) => 
        prevBudgets.map((budget) => 
          budget.id === id ? updatedBudget : budget
        )
      );
      toast.success("Orçamento atualizado com sucesso!");
    } catch (error) {
      console.error("Error updating budget:", error);
      toast.error("Falha ao atualizar orçamento");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const deleteBudget = async (id: string) => {
    setIsLoading(true);
    try {
      await deleteEvent(parseInt(id));
      setBudgets((prevBudgets) => prevBudgets.filter((budget) => budget.id !== id));
      toast.success("Orçamento excluído com sucesso!");
    } catch (error) {
      console.error("Error deleting budget:", error);
      toast.error("Falha ao excluir orçamento");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateStatus = async (id: string, newStatus: BudgetStatus, data?: any) => {
    setIsLoading(true);
    try {
      const budget = budgets.find(b => b.id === id);
      if (!budget) throw new Error("Orçamento não encontrado");

      const updatedBudgetData: BudgetFormData = {
        clientName: budget.clientName,
        phone: budget.phone,
        budgetDate: budget.budgetDate,
        eventDate: budget.eventDate,
        eventType: budget.eventType,
        amount: budget.amount,
        installments: budget.installments,
        installmentsCount: budget.installmentsCount,
        firstPaymentDate: budget.firstPaymentDate
      };

      if (data) {
        if (newStatus === 'sent' || newStatus === 'accepted') {
          updatedBudgetData.amount = data.amount !== undefined ? Number(data.amount) : budget.amount;
        }

        if (newStatus === 'accepted') {
          updatedBudgetData.installments = data.installments !== undefined ? Boolean(data.installments) : budget.installments;
          updatedBudgetData.installmentsCount = data.installmentsCount !== undefined ? Number(data.installmentsCount) : budget.installmentsCount;
          updatedBudgetData.firstPaymentDate = data.firstPaymentDate || budget.firstPaymentDate;

          if (
            updatedBudgetData.installments === undefined ||
            updatedBudgetData.installmentsCount === undefined ||
            !updatedBudgetData.firstPaymentDate
          ) {
            throw new Error("Campos de parcelamento são obrigatórios para status 'accepted'");
          }
        }
      }

      const rejectionReason = newStatus === "rejected" ? data?.rejectionReason ?? "Motivo não informado" : undefined;

      if (newStatus === 'rejected' && !rejectionReason) {
        throw new Error("Motivo da recusa é obrigatório para status 'rejected'");
      }

      const apiData = budgetToApiFormat(updatedBudgetData, newStatus, rejectionReason);
      console.log('Enviando para API:', apiData);
      const response = await updateEvent(parseInt(id), apiData);
      const updatedBudget = apiToBudgetFormat(response);

      setBudgets((prevBudgets) => 
        prevBudgets.map((budget) => 
          budget.id === id ? updatedBudget : budget
        )
      );

      const statusMessages = {
        pending: "Orçamento definido como pendente",
        sent: "Proposta marcada como enviada",
        accepted: "Proposta aceita pelo cliente!",
        rejected: "Proposta recusada pelo cliente"
      };

      toast.success(statusMessages[newStatus]);
    } catch (error) {
      console.error("Error updating budget status:", error);
      toast.error("Falha ao atualizar status do orçamento");
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const getBudget = (id: string) => {
    return budgets.find((budget) => budget.id === id);
  };

  const refreshBudgets = async () => {
    await fetchBudgets();
  };

  return (
    <BudgetContext.Provider value={{ 
      budgets, 
      isLoading,
      error,
      addBudget, 
      updateBudget, 
      deleteBudget,
      updateStatus,
      getBudget,
      refreshBudgets
    }}>
      {children}
    </BudgetContext.Provider>
  );
}