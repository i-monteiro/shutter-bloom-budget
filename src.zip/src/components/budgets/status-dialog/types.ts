
export interface StatusFormData {
  amount: number;
  installments: boolean;
  installmentsCount: number;
  firstPaymentDate?: Date;
  rejectionReason: string;
}
