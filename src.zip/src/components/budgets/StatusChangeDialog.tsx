import { useEffect, useState } from "react";
import { Budget, BudgetStatus } from "@/types/budget";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { AmountField } from "./status-dialog/AmountField";
import { InstallmentsSection } from "./status-dialog/InstallmentsSection";
import { StatusFormData } from "./status-dialog/types";
import { FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

interface StatusChangeDialogProps {
  budget: Budget;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStatusChange: (id: string, newStatus: BudgetStatus, data: any) => void;
  selectedStatus: BudgetStatus;
}

export function StatusChangeDialog({
  budget,
  open,
  onOpenChange,
  onStatusChange,
  selectedStatus
}: StatusChangeDialogProps) {
  const [formValues, setFormValues] = useState({
    amount: budget.amount || 0,
    installments: budget.installments || false,
    installmentsCount: budget.installmentsCount || 1,
    firstPaymentDate: budget.firstPaymentDate,
    rejectionReason: ''
  });

  const form = useForm<StatusFormData>({
    defaultValues: formValues
  });

  useEffect(() => {
    if (open) {
      const newValues = {
        amount: budget.amount || 0,
        installments: budget.installments || false,
        installmentsCount: budget.installmentsCount || 1,
        firstPaymentDate: budget.firstPaymentDate,
        rejectionReason: ''
      };
      setFormValues(newValues);
      form.reset(newValues);
    }
  }, [open, budget, form, selectedStatus]);

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      form.reset();
    }
    onOpenChange(newOpen);
  };

  const onSubmit = (data: StatusFormData) => {
    if (selectedStatus === 'accepted') {
      if (
        data.amount === undefined ||
        data.installments === undefined ||
        data.installmentsCount === undefined ||
        !data.firstPaymentDate
      ) {
        toast.error("Preencha todos os dados de parcelamento para aceitar o orçamento.");
        return;
      }
    }

    if (selectedStatus === 'rejected') {
      if (!data.rejectionReason || data.rejectionReason.trim() === '') {
        toast.error("Motivo da recusa é obrigatório.");
        return;
      }
    }

    const processedData = {
      valorEvento: Number(data.amount),
      iraParcelar: data.installments,
      quantParcelas: Number(data.installmentsCount),
      dataPrimeiroPagamento: data.firstPaymentDate?.toISOString().split('T')[0],
      motivoRecusa: data.rejectionReason
    };

    console.log("Form data being submitted:", processedData);
    onStatusChange(budget.id, selectedStatus, processedData);
    handleOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {selectedStatus === 'sent' ? 'Enviar Orçamento' : 
             selectedStatus === 'accepted' ? 'Aceitar Orçamento' :
             selectedStatus === 'rejected' ? 'Recusar Orçamento' : 
             'Definir como Pendente'}
          </DialogTitle>
          <DialogDescription>
            Preencha as informações necessárias para {
              selectedStatus === 'sent' ? 'enviar o orçamento' : 
              selectedStatus === 'accepted' ? 'aceitar o orçamento' :
              selectedStatus === 'rejected' ? 'recusar o orçamento' : 
              'definir como pendente'
            }.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {(selectedStatus === 'sent' || selectedStatus === 'accepted') && (
              <AmountField form={form} />
            )}

            {selectedStatus === 'accepted' && (
              <InstallmentsSection form={form} />
            )}

            {selectedStatus === 'rejected' && (
              <FormField
                control={form.control}
                name="rejectionReason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Motivo da Recusa</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Informe o motivo da recusa do orçamento"
                        {...field}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            )}

            <div className="flex justify-end gap-3">
              <Button variant="outline" type="button" onClick={() => handleOpenChange(false)}>
                Cancelar
              </Button>
              <Button type="submit">
                Confirmar
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}